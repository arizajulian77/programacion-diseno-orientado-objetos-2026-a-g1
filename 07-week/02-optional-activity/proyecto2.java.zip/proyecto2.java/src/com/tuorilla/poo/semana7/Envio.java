package com.tuorilla.poo.semana7;

public class Envio {

    private String codigo;
    private double pesoKg;

    public Envio(String codigo, double pesoKg) {
        setCodigo(codigo);
        setPesoKg(pesoKg);
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) {
        if (codigo == null || codigo.isBlank())
            throw new IllegalArgumentException("Código vacío");
        this.codigo = codigo;
    }

    public double getPesoKg() { return pesoKg; }
    public void setPesoKg(double pesoKg) {
        if (pesoKg <= 0)
            throw new IllegalArgumentException("Peso inválido");
        this.pesoKg = pesoKg;
    }

    public double calcularCosto() {
        return 0; // base (se sobrescribe)
    }

    public void resumen() {
        System.out.println("Código: " + codigo + " | Peso: " + pesoKg + "kg | Costo: $" + calcularCosto());
    }
}