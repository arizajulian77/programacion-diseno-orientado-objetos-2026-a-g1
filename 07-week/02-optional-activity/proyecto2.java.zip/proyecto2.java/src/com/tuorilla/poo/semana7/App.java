package com.tuorilla.poo.semana7;

import java.util.ArrayList;

public class App {

    public static void main(String[] args) {

        ArrayList<Envio> lista = new ArrayList<>();

        lista.add(new EnvioEstandar("E1", 2));
        lista.add(new EnvioExpress("E2", 1.5));
        lista.add(new EnvioInternacional("E3", 3, "USA"));

        double total = 0;

        for (Envio e : lista) {
            e.resumen();
            total += e.calcularCosto();
        }

        System.out.println("TOTAL: $" + total);
    }
}