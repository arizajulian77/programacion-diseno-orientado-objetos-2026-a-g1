package com.tuorilla.poo.semana6;

public class Administrativo extends Persona {

    private String cargo;

    public Administrativo(String documento, String nombre, String correo, String cargo) {
        super(documento, nombre, correo);
        setCargo(cargo);
    }

    public String getCargo() { return cargo; }

    public void setCargo(String cargo) {
        if (cargo == null || cargo.isBlank())
            throw new IllegalArgumentException("El cargo no puede estar vacío.");
        this.cargo = cargo;
    }

    public void fichaAdministrativo() {
        System.out.println("=== Ficha Administrativo ===");
        System.out.println("Documento : " + getDocumento());
        System.out.println("Nombre    : " + getNombre());
        System.out.println("Correo    : " + getCorreo());
        System.out.println("Cargo     : " + cargo);
    }
}