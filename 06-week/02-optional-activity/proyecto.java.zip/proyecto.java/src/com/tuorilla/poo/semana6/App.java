package com.tuorilla.poo.semana6;

public class App {

    public static void main(String[] args) {

        Persona p = new Persona("1001", "Laura Gómez", "laura@uni.edu.co");
        p.ficha();

        System.out.println();

        Docente d = new Docente("2002", "Carlos Ruiz", "cruiz@uni.edu.co", "Ingeniería de Software");
        d.fichaDocente();

        System.out.println();

        Administrativo a = new Administrativo("3003", "Maria Torres", "mtorres@uni.edu.co", "Coordinadora Académica");
        a.fichaAdministrativo();
    }
}