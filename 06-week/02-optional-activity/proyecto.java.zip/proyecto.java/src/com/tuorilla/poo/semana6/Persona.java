package com.tuorilla.poo.semana6;

public class Persona {

    private String documento;
    private String nombre;
    private String correo;

    public Persona(String documento, String nombre, String correo) {
        setDocumento(documento);
        setNombre(nombre);
        setCorreo(correo);
    }

    public String getDocumento() { return documento; }
    public void setDocumento(String documento) {
        if (documento == null || documento.isBlank())
            throw new IllegalArgumentException("El documento no puede estar vacío.");
        this.documento = documento;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) {
        if (nombre == null || nombre.isBlank())
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        this.nombre = nombre;
    }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) {
        if (correo == null || !correo.contains("@"))
            throw new IllegalArgumentException("El correo debe contener '@'.");
        this.correo = correo;
    }

    public void ficha() {
        System.out.println("=== Ficha Persona ===");
        System.out.println("Documento : " + documento);
        System.out.println("Nombre    : " + nombre);
        System.out.println("Correo    : " + correo);
    }
}