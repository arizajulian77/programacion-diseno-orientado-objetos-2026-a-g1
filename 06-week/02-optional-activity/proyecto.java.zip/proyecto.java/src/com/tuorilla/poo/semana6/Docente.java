package com.tuorilla.poo.semana6;

public class Docente extends Persona {

    private String area;

    public Docente(String documento, String nombre, String correo, String area) {
        super(documento, nombre, correo);
        setArea(area);
    }

    public String getArea() { return area; }

    public void setArea(String area) {
        if (area == null || area.isBlank())
            throw new IllegalArgumentException("El área no puede estar vacía.");
        this.area = area;
    }

    public void fichaDocente() {
        System.out.println("=== Ficha Docente ===");
        System.out.println("Documento : " + getDocumento());
        System.out.println("Nombre    : " + getNombre());
        System.out.println("Correo    : " + getCorreo());
        System.out.println("Área      : " + area);
    }
}